Starfall Legacy - 16-bit Retro SFX Pack

Generated from scratch as original synthesized sound effects for a retro platformer prototype.
Format: WAV, mono, 44.1 kHz, 16-bit PCM.

Included files:
- amb_retro_platformer_soft_loop_01.wav
- sfx_block_bump_01.wav
- sfx_brick_break_01.wav
- sfx_coin_pickup_01.wav
- sfx_coin_pickup_02.wav
- sfx_enemy_stomp_01.wav
- sfx_flagpole_grab_slide_01.wav
- sfx_footstep_grass_01.wav
- sfx_footstep_grass_02.wav
- sfx_jump_01.wav
- sfx_jump_short_02.wav
- sfx_landing_dust_01.wav
- sfx_level_finish_jingle_01.wav
- sfx_level_start_01.wav
- sfx_player_hurt_01.wav
- sfx_portal_enter_01.wav
- sfx_powerup_mushroom_01.wav
- sfx_ui_back_01.wav
- sfx_ui_select_01.wav
- sfx_warning_boss_door_01.wav

Suggested Godot use:
- Import WAV files directly into Godot.
- For short effects, use AudioStreamPlayer or AudioStreamPlayer2D.
- For one-shot SFX, disable looping.
- For amb_retro_platformer_soft_loop_01.wav, enable loop if you want a simple background layer.
- Keep SFX volume around -6 dB to -12 dB and voice/dialogue louder than SFX.
- These are intentionally not sampled from Mario or any copyrighted game; they are original chiptune-style sounds.
